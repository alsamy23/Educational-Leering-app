export enum QuestionType {
  MCQ = 'MCQ',
  WORD_PROBLEM = 'WORD_PROBLEM',
  CASE_STUDY = 'CASE_STUDY',
  VISUAL_ANALYSIS = 'VISUAL_ANALYSIS'
}

export enum StudyFocus {
  SYLLABUS = 'Syllabus',
  PATTERN = 'Exam Pattern',
  TOPICS = 'Specific Topics'
}

export interface UserProfile {
  name: string;
  gradeLevel: string;
  subject: string;
  focus: StudyFocus;
  topic: string;
  level: number; // Progressive level (1, 2, 3...)
  totalQuizzes: number;
}

export interface QuizQuestion {
  id: number;
  type: QuestionType;
  text: string;
  contextMaterial?: string; // Holds the Case Study text or Image Description
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizSession {
  profile: UserProfile;
  questions: QuizQuestion[];
  userAnswers: (number | null)[];
  score: number;
}

export interface Group {
  id: string;
  name: string;
  score: number;
  members: string[];
}

export interface ClassroomSession {
  id: string;
  groups: Group[];
  currentGroupIndex: number;
  subject: string;
  gradeLevel: string;
  topic: string;
  isStarted: boolean;
}

export enum AppScreen {
  ENTRY = 'ENTRY',
  CLASSROOM_SETUP = 'CLASSROOM_SETUP',
  LOADING = 'LOADING',
  QUIZ = 'QUIZ',
  RESULTS = 'RESULTS',
  LEADERBOARD = 'LEADERBOARD',
  API_KEY_REQUIRED = 'API_KEY_REQUIRED'
}
